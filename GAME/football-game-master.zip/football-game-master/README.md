# football-game
A foosball game written in vanilla javascript using HTML5 canvas.

You can play the game: http://prashantbaid.github.io/football-game

# License
MIT License
